EDB Validator v1.2.8

Checks EDB for:

- possible syntax errors (too many to list here)
- invalid unit type references
- invalid faction/culture names
- invalid religious belief references
- invalid hidden_resource references (also checks to make sure the limit on the number of hidden resources has not been exceeded)
- references to non-existent buildings/building levels

How to use:

Requires Java 6 runtime environment to be installed on your box. If you don't have it,
you can download it here: http://java.sun.com/javase/downloads/index.jsp

1. Double-click on the "EDB Validator" shortcut to start the program

2. Select which game the mod is for (RTW/BI/Alex or M2TW/Kingdoms) and configure options (check boxes)

3. Click on the "..." button, browse to the location of your mod, and select it.

4. Click on Validate
 
Assumptions:

- The validator assumes agent types have not been modified (in other words, vanilla types are hard-coded).

Notes:

- Plugins validation is not supported. All plugin defitions will be skipped and won't be included in the "Generate prettified EDB" output.
- Faction and cultures types are cross-checked with descr_sm_factions.txt and descr_cultures.txt
- Unit types are cross-checked with EDU
- Checks export_buildings.txt: for buildings, it checks for {id_name}. For levels, checks for {id}, {id_desc}, and {id_desc_short}
- (RTW) Religious beliefs are checked against those listed in descr_beliefs.txt, if found. If not found, assumes that vanilla religious
  beliefs are used and checks against those.
- (MTW2) Religions are checked against descr_religions.txt

Files the program reads:

- text\export_buildings.txt
- export_descr_buildings.txt
- export_descr_unit.txt
- descr_cultures.txt
- descr_sm_factions.txt
- descr_beliefs.txt (RTW, if present) / descr_religions.txt (MTW2)

Other than EDB itself, these files are not parsed completely, but are only quick-scanned for lines containing ids.

To-do list for future versions:

- Cross-check agent types with descr_characters.txt

What this validator does NOT check (other than what's on the to-do list):

- loops in building levels, i.e. upgrade paths that form a loop
- unit ownership (use RedFox's validator for that, though: http://www.twcenter.net/forums/showthread.php?t=247668)
- presence/absence of building cards
- references to normal, non-hidden resources
- syntax errors in files other the EDB
- for MTW2, it does not check event_type references against descr_events.txt

Change history:

v1.2.8
- Added a shortcut for the default location of java.exe on 64-bit system

v1.2.7
- Changed program locale settings to English. This fixes floating point number parsing (for example, in M2TW recruit_pool
  capability lines) for users whose computers' default locate is set to use something other than dot for decimal separator.
 
v1.2.6
- Added support for weapon_artillery_mechanical capability type for M2TW

v1.2.5
- Fixed a bug with parsing descr_sm_factions.txt and descr_cultures.txt when faction/culture id is immediately followed by a semicolon
- (M2TW) Added support for a few building capabilities that I previously wasn't aware of

v1.2.4
- When a plugin definition is detected, will give a warning and skip over it, rather than abort with error.

v1.2.3
- Interface clean-up
- Minor bug fix in handling intermixed delimiters (both tabs and spaces) when set not to report tabs as errors
- Now will remember last used settings when you restart the program (settings are saved when you run a validation)
- Now works with RS2-like folder structure

v1.2.2
- When reporting errors found in export_buildings.txt, show that the error is in that file rather than in EDB
- Added an optional check for tabs. When enabled, leading/trailing tabs are still considered ok, but tab in the middle of the line are flagged as errors
- Added a check to catch the use of building_present/building_present_min_level requirement condition in recruit capability lines (known cause of CTDs)

v1.2.1
- Fixed the requires port condition. It was already defined as a requirement type, but wasn't being checked for when parsing requirements. Reported by MasterOfNone.
- Fixed the max number of buildings in EDB to be 128 for MTW2. Reported by Augustus Lucifer.

v1.2.0
- Added support for validating MTW2 EDB

v1.1.1
- Fixed a bug that caused an error to be reported when EDB has exactly 64 hidden resources

v1.1.0
- Added code to detect references to non-existent buildings/building levels
- If there is no descr_cultures.txt in the modfolder, will look for it in the vanilla folder
- Minor UI tweaks

v1.0.4
- Added a check to make sure the maximum allowed number of hidden resources (i.e. 64) has not been exceeded
- Added detection of references to non-existent hidden resources

v1.0.3
- Now checks references to religious beliefs against those listed in descr_beliefs.txt (previously only worked with vanilla religions).

v1.0.2
- Replaced checkEDB.bat with a shortcut, so now you'll get no DOS pop-up window in the background when starting the program.
- Fixed a bug in the "Generate prettified EDB" functionality where the generated output missed requirements for all but the very first building level. Thanks to Redfox for spotting this one.

v1.0.1
- Fixed a bug that caused an error to be reported if there was a comment
at the end of the line. Thanks to dvk901 for reporting it.

v1
- Original public release
